
export enum CompressionQualityPreset {
  Low = 'Low',
  Medium = 'Medium',
  High = 'High',
  Custom = 'Custom',
}

export interface ImageFileProcessed {
  id: string;
  file: File;
  originalSrc: string;
  originalSize: number;
  originalWidth: number;
  originalHeight: number;
  
  compressedSrc: string | null;
  compressedSize: number | null;
  compressedBlob: Blob | null;
  
  currentQualitySetting: number; // Numeric value 0.0 to 1.0
  
  // For resizing
  inputWidth: string; // Stored as string for input field binding
  inputHeight: string; // Stored as string for input field binding
  
  isCompressing: boolean;
  isCompressed: boolean;
  error: string | null;
}

export interface Dimensions {
  width: number;
  height: number;
}

export interface CompressionResult {
  dataUrl: string;
  blob: Blob;
  size: number;
  width: number;
  height: number;
}
    