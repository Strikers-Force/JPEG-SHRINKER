
import { CompressionResult, Dimensions } from '../types';

export const loadImageDimensions = (file: File): Promise<Dimensions> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        if (img.width > 0 && img.height > 0) {
          resolve({ width: img.width, height: img.height });
        } else {
          reject(new Error(`Invalid image dimensions: ${img.width}x${img.height}. File may be corrupted or not a valid image.`));
        }
      };
      img.onerror = (err) => {
        reject(new Error(`Failed to load image for dimension reading: ${err instanceof Error ? err.message : String(err)}`));
      };
      if (e.target?.result) {
        img.src = e.target.result as string;
      } else {
        reject(new Error("Could not read file for dimensions."));
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};


export const compressImage = async (
  file: File,
  quality: number, // 0 to 1
  targetDimensions?: Partial<Dimensions> // Optional target width/height
): Promise<CompressionResult> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let newWidth = img.width;
        let newHeight = img.height;

        if (targetDimensions) {
          if (targetDimensions.width && targetDimensions.height) {
            newWidth = targetDimensions.width;
            newHeight = targetDimensions.height;
          } else if (targetDimensions.width) {
            newWidth = targetDimensions.width;
            if (img.width > 0) { // Prevent division by zero
                newHeight = (img.height * newWidth) / img.width;
            } else { // Cannot maintain aspect ratio if original width is 0
                newHeight = targetDimensions.height || img.height; // Fallback or use original
            }
          } else if (targetDimensions.height) {
            newHeight = targetDimensions.height;
            if (img.height > 0) { // Prevent division by zero
                newWidth = (img.width * newHeight) / img.height;
            } else { // Cannot maintain aspect ratio if original height is 0
                newWidth = targetDimensions.width || img.width; // Fallback or use original
            }
          }
        }
        
        newWidth = Math.round(newWidth);
        newHeight = Math.round(newHeight);

        // Validate dimensions before creating canvas
        if (!(newWidth > 0 && newHeight > 0 && isFinite(newWidth) && isFinite(newHeight))) {
          return reject(new Error(`Invalid target dimensions for compression: ${newWidth}x${newHeight}. Dimensions must be positive finite numbers.`));
        }

        const canvas = document.createElement('canvas');
        canvas.width = newWidth;
        canvas.height = newHeight;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          return reject(new Error('Failed to get canvas context'));
        }

        ctx.drawImage(img, 0, 0, newWidth, newHeight);

        canvas.toBlob(
          (blob) => {
            if (!blob) {
              return reject(new Error('Canvas toBlob failed. This can happen with invalid dimensions or quality settings.'));
            }
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            resolve({
              dataUrl,
              blob,
              size: blob.size,
              width: newWidth,
              height: newHeight,
            });
          },
          'image/jpeg',
          quality
        );
      };
      img.onerror = (err) => reject(new Error(`Failed to load image for compression: ${err instanceof Error ? err.message : String(err)}`));
      if (event.target?.result) {
        img.src = event.target.result as string;
      } else {
         reject(new Error("Could not read file for compression."));
      }
    };
    reader.onerror = (err) => reject(new Error(`FileReader error during compression: ${err instanceof Error ? err.message : String(err)}`));
    reader.readAsDataURL(file);
  });
};
