
import { ImageFileProcessed } from '../types';

declare var JSZip: any; // JSZip is loaded from CDN

export const createZip = async (images: ImageFileProcessed[]): Promise<Blob> => {
  if (typeof JSZip === 'undefined') {
    throw new Error('JSZip library is not loaded.');
  }
  const zip = new JSZip();
  
  images.forEach(imageItem => {
    if (imageItem.compressedBlob) {
      // Create a unique name if multiple files have the same name (though original names are usually unique)
      const fileName = `compressed_${imageItem.file.name}`;
      zip.file(fileName, imageItem.compressedBlob);
    } else if (imageItem.file) {
      // Fallback to original if not compressed, though UI should prevent this path for zipping
      zip.file(imageItem.file.name, imageItem.file);
    }
  });

  return zip.generateAsync({ type: 'blob', compression: "DEFLATE", compressionOptions: { level: 9 } });
};

export const downloadBlob = (blob: Blob, filename: string): void => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
    