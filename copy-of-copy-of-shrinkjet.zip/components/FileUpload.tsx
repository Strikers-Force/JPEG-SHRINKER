
import React, { useCallback, useState } from 'react';
import { ACCEPTED_FILE_TYPES, MAX_FILE_SIZE_BYTES } from '../constants';
import UploadIcon from './icons/UploadIcon';

interface FileUploadProps {
  onFilesUploaded: (files: File[]) => void;
  disabled?: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFilesUploaded, disabled }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleFileFilter = (files: FileList | null): File[] => {
    if (!files) return [];
    const validFiles: File[] = [];
    const oversizedFiles: string[] = [];

    Array.from(files).forEach(file => {
      if (ACCEPTED_FILE_TYPES.includes(file.type) && file.type.startsWith('image/')) {
        if (file.size <= MAX_FILE_SIZE_BYTES) {
          validFiles.push(file);
        } else {
          oversizedFiles.push(file.name);
        }
      }
    });

    if (oversizedFiles.length > 0) {
      alert(`Some files were not uploaded because they exceed the 10MB size limit: ${oversizedFiles.join(', ')}`);
    }
    return validFiles;
  };

  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
    if (disabled) return;
    const newFiles = handleFileFilter(event.dataTransfer.files);
    if (newFiles.length > 0) {
      onFilesUploaded(newFiles);
    }
  }, [onFilesUploaded, disabled]);

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    if (disabled) return;
    if (!isDragging) setIsDragging(true);
  }, [isDragging, disabled]);

  const handleDragLeave = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    if (disabled) return;
    setIsDragging(false);
  }, [disabled]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (disabled) return;
    const newFiles = handleFileFilter(event.target.files);
     if (newFiles.length > 0) {
      onFilesUploaded(newFiles);
    }
    event.target.value = ''; // Reset input to allow uploading same file again
  };

  return (
    <div
      className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors duration-200 ease-in-out
                  ${disabled ? 'bg-gray-200 border-gray-300 cursor-not-allowed' : 
                  isDragging ? 'border-primary bg-blue-50' : 'border-gray-300 hover:border-primary'}`}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
    >
      <input
        type="file"
        id="fileUpload"
        multiple
        accept={ACCEPTED_FILE_TYPES.join(',')}
        onChange={handleFileChange}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        disabled={disabled}
      />
      <label htmlFor="fileUpload" className={`flex flex-col items-center justify-center ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
        <UploadIcon className={`w-12 h-12 mb-3 ${disabled ? 'text-gray-400' : 'text-primary'}`} />
        <p className={`text-lg font-medium ${disabled ? 'text-gray-500' : 'text-gray-700'}`}>
          Drag & drop JPEG files here (max 10MB each)
        </p>
        <p className={`${disabled ? 'text-gray-400' : 'text-gray-500'} text-sm`}>or click to select files</p>
        {isDragging && !disabled && (
          <p className="mt-2 text-sm text-primary font-semibold">Drop files to upload</p>
        )}
      </label>
    </div>
  );
};

export default FileUpload;