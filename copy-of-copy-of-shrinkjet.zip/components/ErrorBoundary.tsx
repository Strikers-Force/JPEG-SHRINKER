import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
    // You could also log the error to an error reporting service here
  }

  private handleRefresh = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-base-100 p-4 text-center">
          <svg className="w-16 h-16 text-error mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <h1 className="text-2xl font-bold text-error mb-2">Oops! Something went wrong.</h1>
          <p className="text-neutral-content mb-4">
            We're sorry for the inconvenience. An unexpected error occurred.
          </p>
          {this.state.error && (
            <details className="mb-4 p-2 bg-gray-200 dark:bg-gray-700 rounded text-left text-xs w-full max-w-md">
                <summary className="cursor-pointer font-medium text-gray-700 dark:text-gray-300">Error Details (for developers)</summary>
                <pre className="mt-1 whitespace-pre-wrap break-all">
                    {this.state.error.toString()}
                    {this.state.error.stack && `\n${this.state.error.stack}`}
                </pre>
            </details>
          )}
          <button
            onClick={this.handleRefresh}
            className="px-4 py-2 text-white bg-primary rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            Refresh Page
          </button>
           <p className="text-sm text-gray-500 mt-6">
            If the problem persists, please contact support or try again later.
          </p>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
