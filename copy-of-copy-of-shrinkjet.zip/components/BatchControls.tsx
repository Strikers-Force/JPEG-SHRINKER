
import React from 'react';
import { CompressionQualityPreset, ImageFileProcessed } from '../types';
import { QUALITY_PRESET_MAP } from '../constants';
import LoadingSpinner from './LoadingSpinner';
import ZipIcon from './icons/ZipIcon';

interface BatchControlsProps {
  images: ImageFileProcessed[];
  onBatchCompress: (quality: number) => void;
  onDownloadZip: () => void;
  isBatchProcessing: boolean;
  isZipping: boolean;
  globalQuality: number;
  setGlobalQuality: (quality: number) => void;
}

const BatchControls: React.FC<BatchControlsProps> = ({
  images,
  onBatchCompress,
  onDownloadZip,
  isBatchProcessing,
  isZipping,
  globalQuality,
  setGlobalQuality,
}) => {
  const canProcess = images.length > 0;
  const canZip = images.some(img => img.compressedBlob);

  return (
    <div className="bg-white shadow-md rounded-lg p-4 my-6 space-y-4">
      <h3 className="text-xl font-semibold text-gray-800">Batch Operations</h3>
      
      <div>
        <label htmlFor="globalQuality" className="block text-sm font-medium text-gray-700">
          Global Quality: {globalQuality.toFixed(2)}
        </label>
        <div className="flex items-center gap-2 mt-1">
          <input
            type="range"
            id="globalQuality"
            min="0.1"
            max="1"
            step="0.01"
            value={globalQuality}
            onChange={(e) => setGlobalQuality(parseFloat(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-primary flex-grow"
            disabled={isBatchProcessing || !canProcess}
          />
          <div className="flex gap-1">
            {(Object.keys(QUALITY_PRESET_MAP) as Array<CompressionQualityPreset>).filter(k => k !== CompressionQualityPreset.Custom).map((presetKey) => (
              <button
                key={presetKey}
                onClick={() => setGlobalQuality(QUALITY_PRESET_MAP[presetKey])}
                className={`px-2 py-1 text-xs font-medium rounded-md border
                            ${globalQuality === QUALITY_PRESET_MAP[presetKey] ? 'bg-primary text-white border-primary' : 'bg-gray-100 text-gray-700 hover:bg-gray-200 border-gray-300'}
                            disabled:opacity-50 disabled:cursor-not-allowed`}
                disabled={isBatchProcessing || !canProcess}
              >
                {presetKey}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => onBatchCompress(globalQuality)}
          disabled={!canProcess || isBatchProcessing || isZipping}
          className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:bg-gray-400 flex items-center gap-2"
        >
          {isBatchProcessing ? <LoadingSpinner size="w-4 h-4" color="text-white" /> : null}
          {isBatchProcessing ? 'Compressing All...' : 'Compress All Images'}
        </button>
        <button
          onClick={onDownloadZip}
          disabled={!canZip || isZipping || isBatchProcessing}
          className="px-4 py-2 text-sm font-medium text-white bg-accent rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent disabled:bg-gray-400 flex items-center gap-2"
        >
          {isZipping ? <LoadingSpinner size="w-4 h-4" color="text-white" /> : <ZipIcon className="w-5 h-5" />}
          {isZipping ? 'Zipping...' : 'Download All as ZIP'}
        </button>
      </div>
    </div>
  );
};

export default BatchControls;
    