import React, { useState, useCallback, useEffect } from 'react';
import { ImageFileProcessed, Dimensions } from '../types';
import { DEFAULT_COMPRESSION_QUALITY } from '../constants';
import LoadingSpinner from './LoadingSpinner';
import DownloadIcon from './icons/DownloadIcon';
import TrashIcon from './icons/TrashIcon';

interface ImagePreviewCardProps {
  imageFile: ImageFileProcessed;
  onCompress: (id: string, quality: number, dimensions?: Partial<Dimensions>) => void;
  onRemove: (id: string) => void;
  onUpdateSettings: (id: string, settings: Partial<Pick<ImageFileProcessed, 'currentQualitySetting' | 'inputWidth' | 'inputHeight'>>) => void;
}

const formatBytes = (bytes: number | null | undefined, decimals = 2) => {
  if (bytes === null || typeof bytes === 'undefined' || isNaN(bytes) || bytes <= 0) return '0 Bytes'; // Ensure bytes is a positive number
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

const ImagePreviewCard: React.FC<ImagePreviewCardProps> = ({ imageFile, onCompress, onRemove, onUpdateSettings }) => {
  const [quality, setQuality] = useState<number>(imageFile.currentQualitySetting);
  const [inputWidth, setInputWidth] = useState<string>(imageFile.inputWidth);
  const [inputHeight, setInputHeight] = useState<string>(imageFile.inputHeight);

  useEffect(() => {
    setQuality(imageFile.currentQualitySetting);
    setInputWidth(imageFile.inputWidth);
    setInputHeight(imageFile.inputHeight);
  }, [imageFile.currentQualitySetting, imageFile.inputWidth, imageFile.inputHeight]);

  const handleQualityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuality = parseFloat(e.target.value);
    setQuality(newQuality);
    onUpdateSettings(imageFile.id, { currentQualitySetting: newQuality });
  };

  const handleDimensionChange = (e: React.ChangeEvent<HTMLInputElement>, dimension: 'width' | 'height') => {
    const value = e.target.value;
    let newWidthString = dimension === 'width' ? value : inputWidth;
    let newHeightString = dimension === 'height' ? value : inputHeight;

    const numericValue = parseInt(value);
    const { originalWidth, originalHeight } = imageFile;

    if (!isNaN(numericValue) && numericValue > 0 && originalWidth > 0 && originalHeight > 0) {
      if (dimension === 'width') {
        newHeightString = Math.max(1, Math.round((numericValue * originalHeight) / originalWidth)).toString();
      } else { // dimension === 'height'
        newWidthString = Math.max(1, Math.round((numericValue * originalWidth) / originalHeight)).toString();
      }
    } else if (value === '') { 
        // If one dimension is cleared, clear the other to signify using original dimensions or manual input for both
        if (dimension === 'width') newHeightString = '';
        else newWidthString = '';
    }
    
    setInputWidth(newWidthString);
    setInputHeight(newHeightString);
    onUpdateSettings(imageFile.id, { inputWidth: newWidthString, inputHeight: newHeightString });
  };
  
  const handleCompressClick = () => {
    const targetWidth = parseInt(inputWidth);
    const targetHeight = parseInt(inputHeight);
    const dimensions: Partial<Dimensions> = {};

    // Only pass dimensions if they are valid positive numbers
    if (!isNaN(targetWidth) && targetWidth > 0) dimensions.width = targetWidth;
    if (!isNaN(targetHeight) && targetHeight > 0) dimensions.height = targetHeight;
    
    // If one is specified and positive, but the other is not (or zero), it implies using original for that or aspect ratio if only one is passed.
    // The compressImage service will handle aspect ratio if only one is provided.
    // If both are NaN or <=0 after parse, no dimensions object is passed, so original size is used.
    const useSpecificDimensions = (dimensions.width && dimensions.height) || dimensions.width || dimensions.height;

    onCompress(imageFile.id, quality, useSpecificDimensions ? dimensions : undefined);
  };

  const handleDownload = () => {
    if (imageFile.compressedBlob) {
      const link = document.createElement('a');
      link.href = URL.createObjectURL(imageFile.compressedBlob);
      link.download = `compressed_${imageFile.file.name}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);
    }
  };

  // Determine display dimensions for compressed image info
  const displayCompressedWidth = imageFile.isCompressed && imageFile.compressedBlob ? (parseInt(imageFile.inputWidth) > 0 ? parseInt(imageFile.inputWidth) : imageFile.originalWidth) : imageFile.originalWidth;
  const displayCompressedHeight = imageFile.isCompressed && imageFile.compressedBlob ? (parseInt(imageFile.inputHeight) > 0 ? parseInt(imageFile.inputHeight) : imageFile.originalHeight) : imageFile.originalHeight;


  return (
    <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col gap-3 border border-gray-200">
      <div className="flex flex-col md:flex-row gap-4 items-start">
        <div className="w-full md:w-1/3 flex-shrink-0">
            <p className="text-sm font-medium text-gray-500 truncate mb-1" title={imageFile.file.name}>{imageFile.file.name}</p>
            <img src={imageFile.originalSrc} alt="Original Preview" className="rounded-md w-full h-auto object-contain max-h-48 border" />
            <p className="text-xs text-gray-500 mt-1">Original: {formatBytes(imageFile.originalSize)} ({imageFile.originalWidth}x{imageFile.originalHeight})</p>
        </div>
        <div className="w-full md:w-1/3 flex-shrink-0">
            <p className="text-sm font-medium text-gray-500 mb-1">Compressed</p>
            {imageFile.isCompressing ? (
                <div className="flex items-center justify-center h-48 border rounded-md bg-gray-50">
                    <LoadingSpinner />
                </div>
            ) : imageFile.compressedSrc ? (
                <img src={imageFile.compressedSrc} alt="Compressed Preview" className="rounded-md w-full h-auto object-contain max-h-48 border" />
            ) : (
                <div className="flex items-center justify-center h-48 border rounded-md bg-gray-50 text-gray-400 text-sm">No preview</div>
            )}
            {imageFile.compressedSize !== null && imageFile.isCompressed && (
                 <p className="text-xs text-green-600 mt-1">Compressed: {formatBytes(imageFile.compressedSize)} ({displayCompressedWidth}x{displayCompressedHeight})</p>
            )}
             {imageFile.error && <p className="text-xs text-red-500 mt-1">{imageFile.error}</p>}
        </div>
         <div className="w-full md:w-1/3 space-y-3">
            <div>
                <label htmlFor={`quality-${imageFile.id}`} className="block text-sm font-medium text-gray-700">Quality: {quality.toFixed(2)}</label>
                <input
                    type="range"
                    id={`quality-${imageFile.id}`}
                    min="0.1"
                    max="1"
                    step="0.01"
                    value={quality}
                    onChange={handleQualityChange}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-primary"
                    disabled={imageFile.isCompressing}
                />
            </div>
            <div className="grid grid-cols-2 gap-2">
                <div>
                    <label htmlFor={`width-${imageFile.id}`} className="block text-xs font-medium text-gray-700">Width (px)</label>
                    <input
                        type="number"
                        id={`width-${imageFile.id}`}
                        value={inputWidth}
                        onChange={(e) => handleDimensionChange(e, 'width')}
                        placeholder={imageFile.originalWidth.toString()}
                        min="1" // Basic HTML5 validation
                        className="mt-1 block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm disabled:bg-gray-100"
                        disabled={imageFile.isCompressing}
                    />
                </div>
                <div>
                    <label htmlFor={`height-${imageFile.id}`} className="block text-xs font-medium text-gray-700">Height (px)</label>
                    <input
                        type="number"
                        id={`height-${imageFile.id}`}
                        value={inputHeight}
                        onChange={(e) => handleDimensionChange(e, 'height')}
                        placeholder={imageFile.originalHeight.toString()}
                        min="1" // Basic HTML5 validation
                        className="mt-1 block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm disabled:bg-gray-100"
                        disabled={imageFile.isCompressing}
                    />
                </div>
            </div>
        </div>
      </div>
      <div className="mt-auto pt-3 flex flex-wrap gap-2 justify-end border-t border-gray-200">
          <button
            onClick={handleCompressClick}
            disabled={imageFile.isCompressing}
            className="px-3 py-1.5 text-sm font-medium text-white bg-primary rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:bg-gray-300 flex items-center gap-1"
            aria-label={imageFile.isCompressing ? 'Compressing image' : (imageFile.isCompressed ? 'Recompress image' : 'Compress image')}
            aria-live="polite"
          >
            {imageFile.isCompressing ? <LoadingSpinner size="w-4 h-4" color="text-white" /> : null}
            {imageFile.isCompressing ? 'Compressing...' : (imageFile.isCompressed ? 'Re-Compress' : 'Compress')}
          </button>
          <button
            onClick={handleDownload}
            disabled={!imageFile.compressedBlob || imageFile.isCompressing}
            className="px-3 py-1.5 text-sm font-medium text-white bg-accent rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent disabled:bg-gray-300 flex items-center gap-1"
            aria-label="Download compressed image"
          >
            <DownloadIcon className="w-4 h-4" /> Download
          </button>
          <button
            onClick={() => onRemove(imageFile.id)}
            disabled={imageFile.isCompressing}
            className="px-3 py-1.5 text-sm font-medium text-white bg-secondary rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary disabled:bg-gray-300 flex items-center gap-1"
            aria-label="Remove image"
          >
           <TrashIcon className="w-4 h-4" /> Remove
          </button>
        </div>
    </div>
  );
};

export default ImagePreviewCard;
