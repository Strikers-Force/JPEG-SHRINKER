import React from 'react';

const ShrinkJetLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" {...props}>
    <defs>
      <linearGradient id="shrinkJetMainGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: 'rgb(var(--color-primary))', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: 'rgb(var(--color-accent))', stopOpacity: 1}} />
      </linearGradient>
       <linearGradient id="shrinkJetHighlightGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: 'rgb(var(--color-info))', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: 'rgb(var(--color-primary))', stopOpacity: 1}} />
      </linearGradient>
    </defs>
    {/* Background element for depth */}
    <circle cx="50" cy="50" r="48" fill="rgb(var(--color-base-100))" opacity="0.1" />
    
    {/* Main circle shape */}
    <circle cx="50" cy="50" r="45" fill="url(#shrinkJetMainGradient)" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5"/>
    
    {/* Inner "compression" arrows symbolic representation */}
    {/* Left Arrow */}
    <path d="M40 35 L50 45 L40 55 L45 55 L55 45 L45 35 Z" fill="rgba(255,255,255,0.8)" />
    {/* Right Arrow */}
    <path d="M60 35 L50 45 L60 55 L55 55 L45 45 L55 35 Z" fill="rgba(255,255,255,0.8)" />

    {/* Optional: Stylized S initial - uncomment and adjust if desired */}
    {/*
    <text x="50" y="62" fontFamily="Arial, Helvetica, sans-serif" fontSize="40" fontWeight="bold" textAnchor="middle" fill="white">
      S J
    </text>
    */}
  </svg>
);

export default ShrinkJetLogo;
