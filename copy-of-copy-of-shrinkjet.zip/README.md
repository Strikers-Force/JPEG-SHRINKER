# ShrinkJet - JPEG Image Compressor (Vite Edition)

ShrinkJet is a powerful, client-side web application designed to compress and resize your JPEG images with ease and efficiency. Optimize your images for web use, reducing file sizes while maintaining visual quality, all directly in your browser. This version is configured for building with Vite.

<!-- TODO: Add Netlify/Vercel status badges once deployed -->
<!--
[![Netlify Status](https://api.netlify.com/api/v1/badges/YOUR_NETLIFY_SITE_ID/deploy-status)](https://app.netlify.com/sites/YOUR_NETLIFY_SITE_NAME/deploys)
[![Vercel Status](https://vercel.com/YOUR_VERCEL_USERNAME/YOUR_PROJECT_NAME/shield)](https://vercel.com/YOUR_VERCEL_USERNAME/YOUR_PROJECT_NAME)
-->

## ✨ Features

*   **Client-Side Processing:** Images are processed in your browser, ensuring privacy and speed. No uploads to external servers.
*   **JPEG Compression:** Adjust compression quality with a simple slider or presets.
*   **Image Resizing:** Resize images by width or height, maintaining aspect ratio.
*   **Batch Processing:** Upload and compress multiple images at once.
*   **Global Controls:** Apply compression quality settings to all uploaded images.
*   **Instant Previews:** See original and compressed image previews side-by-side.
*   **ZIP Download:** Download all compressed images conveniently in a single ZIP file.
*   **Responsive Design:** Works seamlessly on desktop and mobile devices.
*   **Error Handling:** Graceful error handling for file uploads and processing.
*   **Drag & Drop:** Easy file uploading via drag and drop or file selector.
*   **Dark Mode:** Theme adapts to system preference.

## 🚀 Tech Stack

*   **Framework:** React (v19)
*   **Language:** TypeScript
*   **Build Tool:** Vite
*   **Styling:** Tailwind CSS (via CDN)
*   **Packaging (for downloads):** JSZip (via CDN)

## 🔧 Getting Started & Development

1.  **Clone the repository (if applicable):**
    ```bash
    git clone <your-repo-url>
    cd shrinkjet
    ```
2.  **Install dependencies:**
    ```bash
    npm install 
    # or yarn install / pnpm install
    ```
3.  **Run the development server:**
    ```bash
    npm run dev
    ```
    This will start the Vite development server, typically at `http://localhost:5173`.

4.  **Build for production:**
    ```bash
    npm run build
    ```
    This command first runs `tsc` for type checking and then `vite build` to create a production-ready build in the `dist/` directory.

5.  **Preview production build locally:**
    ```bash
    npm run preview
    ```

## 🌐 Deployment

ShrinkJet is ready for deployment on platforms like Netlify or Vercel.

### General Settings for Netlify/Vercel:

*   **Build Command:** `npm run build` (or `vite build` if you prefer to skip the separate `tsc` step in CI, though `tsc && vite build` is safer for catching type errors before bundling)
*   **Publish/Output Directory:** `dist`
*   **Node.js Version:** Choose a recent LTS version (e.g., 18.x or 20.x).

### Deploying via Git Integration (Recommended):

1.  Push your project to a GitHub, GitLab, or Bitbucket repository.
2.  **Netlify:**
    *   Log in to Netlify.
    *   Click "Add new site" -> "Import an existing project".
    *   Connect to your Git provider and select your repository.
    *   Netlify should automatically detect Vite settings. If not, configure the Build Command and Publish Directory as above.
    *   Deploy site.
3.  **Vercel:**
    *   Log in to Vercel.
    *   Click "Add New..." -> "Project".
    *   Connect to your Git provider and select your repository.
    *   Vercel should automatically detect it as a Vite project and configure settings. Verify them.
    *   Deploy.

### Deploying via Drag and Drop:

1.  Run the build command locally: `npm run build`.
2.  This will create a `dist/` folder.
3.  **Netlify:** Drag the `dist/` folder to the deploy area in the Netlify UI ("Sites" page).
4.  **Vercel:** While Vercel primarily focuses on Git-based deployments, you can use the Vercel CLI for manual deployments:
    *   Install Vercel CLI: `npm install -g vercel`
    *   Navigate to your project directory.
    *   Run `vercel` and follow the prompts. To deploy a prebuilt static site from the `dist` folder, you might use `vercel --prebuilt`. Check Vercel documentation for the latest CLI commands for static site deployment.

## 🖼️ Open Graph Image

For better social media sharing, create an Open Graph image (e.g., `og-image.png`, recommended size 1200x630px) and place it in the `public/` directory. Then, update the `YOUR_OG_IMAGE_URL` placeholders in `index.html` to `/og-image.png` (or the full URL if hosted elsewhere). Also, replace `YOUR_DEPLOYED_APP_URL` with your actual live URL.

## 📄 License

This project is licensed under the MIT License.

---

Powered by **ShrinkJet**
