import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // If your index.tsx is not in root and you need to specify, use:
  // resolve: {
  //   alias: {
  //     '/index.tsx': './index.tsx', // Or the correct path to your main TSX file
  //   },
  // },
  // Vite will automatically pick up index.html in the root.
  // The <script type="module" src="/index.tsx"></script> in your index.html
  // will point to the index.tsx file in your project root.
});
