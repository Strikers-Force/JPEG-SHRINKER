
import { CompressionQualityPreset } from './types';

export const QUALITY_PRESET_MAP: Record<CompressionQualityPreset, number> = {
  [CompressionQualityPreset.Low]: 0.5,
  [CompressionQualityPreset.Medium]: 0.75,
  [CompressionQualityPreset.High]: 0.9,
  [CompressionQualityPreset.Custom]: 0.75, // Default for custom
};

export const DEFAULT_COMPRESSION_QUALITY: number = QUALITY_PRESET_MAP[CompressionQualityPreset.Medium];

export const ACCEPTED_FILE_TYPES = ['image/jpeg', 'image/jpg'];

export const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB
