
import React, { useState, useCallback, useEffect } from 'react';
import FileUpload from './components/FileUpload';
import ImagePreviewCard from './components/ImagePreviewCard';
import BatchControls from './components/BatchControls';
// AITipDisplay and getOptimizationTip are removed
import { ImageFileProcessed, CompressionResult, Dimensions } from './types';
import { loadImageDimensions, compressImage } from './services/imageService';
import { createZip, downloadBlob } from './services/zipService';
import { DEFAULT_COMPRESSION_QUALITY } from './constants';
import ShrinkJetLogo from './components/icons/ShrinkJetLogo';
// DonationButton import removed


const App: React.FC = () => {
  const [uploadedImages, setUploadedImages] = useState<ImageFileProcessed[]>([]);
  const [isBatchProcessing, setIsBatchProcessing] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);
  const [globalCompressionQuality, setGlobalCompressionQuality] = useState<number>(DEFAULT_COMPRESSION_QUALITY);


  const handleFilesUploaded = useCallback(async (files: File[]) => {
    const newImageFilesPromises = files.map(async (file) => {
      const id = crypto.randomUUID();
      const originalSrc = URL.createObjectURL(file);
      try {
        const { width, height } = await loadImageDimensions(file);
        return {
          id,
          file,
          originalSrc,
          originalSize: file.size,
          originalWidth: width,
          originalHeight: height,
          compressedSrc: null,
          compressedSize: null,
          compressedBlob: null,
          currentQualitySetting: globalCompressionQuality,
          inputWidth: width.toString(),
          inputHeight: height.toString(),
          isCompressing: false,
          isCompressed: false,
          error: null,
        } as ImageFileProcessed;
      } catch (error) {
        console.error("Error loading image dimensions:", error);
        URL.revokeObjectURL(originalSrc); 
        return null; 
      }
    });

    const newImageFiles = (await Promise.all(newImageFilesPromises)).filter(img => img !== null) as ImageFileProcessed[];
    
    setUploadedImages(prev => {
        const combined = [...prev, ...newImageFiles];
        return combined;
    });
  }, [globalCompressionQuality]);

  const updateImageState = useCallback((id: string, updates: Partial<ImageFileProcessed>) => {
    setUploadedImages(prev => prev.map(img => img.id === id ? { ...img, ...updates } : img));
  }, []);

  const handleCompressImage = useCallback(async (id: string, quality: number, dimensions?: Partial<Dimensions>) => {
    const imageToCompress = uploadedImages.find(img => img.id === id);
    if (!imageToCompress) return;

    updateImageState(id, { isCompressing: true, error: null });
    try {
      const targetWidth = dimensions?.width || parseInt(imageToCompress.inputWidth) || imageToCompress.originalWidth;
      const targetHeight = dimensions?.height || parseInt(imageToCompress.inputHeight) || imageToCompress.originalHeight;
      
      const result: CompressionResult = await compressImage(imageToCompress.file, quality, {width: targetWidth, height: targetHeight});
      
      if (imageToCompress.compressedSrc) {
        URL.revokeObjectURL(imageToCompress.compressedSrc);
      }

      updateImageState(id, {
        compressedSrc: result.dataUrl,
        compressedBlob: result.blob,
        compressedSize: result.size,
        isCompressing: false,
        isCompressed: true,
        error: null,
        inputWidth: result.width.toString(), 
        inputHeight: result.height.toString(),
      });
    } catch (error) {
      console.error("Compression error:", error);
      updateImageState(id, { isCompressing: false, error: error instanceof Error ? error.message : 'Compression failed' });
    }
  }, [uploadedImages, updateImageState]);

  const handleRemoveImage = useCallback((id: string) => {
    setUploadedImages(prev => {
      const imageToRemove = prev.find(img => img.id === id);
      if (imageToRemove) {
        URL.revokeObjectURL(imageToRemove.originalSrc);
        if (imageToRemove.compressedSrc) {
          URL.revokeObjectURL(imageToRemove.compressedSrc);
        }
      }
      return prev.filter(img => img.id !== id);
    });
  }, []);

  const handleUpdateImageSettings = useCallback((id: string, settings: Partial<Pick<ImageFileProcessed, 'currentQualitySetting' | 'inputWidth' | 'inputHeight'>>) => {
    updateImageState(id, settings);
  }, [updateImageState]);
  
  const handleBatchCompress = useCallback(async (quality: number) => {
    setIsBatchProcessing(true);
    // Apply global quality to all images before processing them.
    // This ensures that if a user changes global quality and hits "Compress All", that new quality is used.
    const imagesToProcess = uploadedImages.map(img => ({...img, currentQualitySetting: quality }));
    setUploadedImages(imagesToProcess);


    for (const image of imagesToProcess) {
      let dims: Partial<Dimensions> | undefined = undefined;
      const parsedInputWidth = parseInt(image.inputWidth);
      const parsedInputHeight = parseInt(image.inputHeight);

      // Determine if custom dimensions should be used
      // Use parsed dimensions if they are valid and different from original, or if explicitly set.
      // If input fields are empty or invalid, compressImage service will use original dimensions.
      const useOriginalWidth = isNaN(parsedInputWidth) || parsedInputWidth <= 0;
      const useOriginalHeight = isNaN(parsedInputHeight) || parsedInputHeight <= 0;

      if (!useOriginalWidth || !useOriginalHeight) {
        dims = {};
        if (!useOriginalWidth) dims.width = parsedInputWidth;
        if (!useOriginalHeight) dims.height = parsedInputHeight;
      }
      
      await handleCompressImage(image.id, image.currentQualitySetting, dims);
    }
    setIsBatchProcessing(false);
  }, [uploadedImages, handleCompressImage, updateImageState]); 

  const handleDownloadZip = useCallback(async () => {
    setIsZipping(true);
    try {
      const imagesToZip = uploadedImages.filter(img => img.compressedBlob);
      if (imagesToZip.length === 0) {
        alert("No compressed images to download.");
        setIsZipping(false);
        return;
      }
      const zipBlob = await createZip(imagesToZip);
      downloadBlob(zipBlob, 'shrunk_images.zip');
    } catch (error) {
      console.error("ZIP creation error:", error);
      alert(error instanceof Error ? error.message : 'Failed to create ZIP file.');
    } finally {
      setIsZipping(false);
    }
  }, [uploadedImages]);

  useEffect(() => {
    return () => {
      uploadedImages.forEach(img => {
        URL.revokeObjectURL(img.originalSrc);
        if (img.compressedSrc) {
          URL.revokeObjectURL(img.compressedSrc);
        }
      });
    };
  }, [uploadedImages]);


  return (
    <div className="container mx-auto p-4 md:p-8 max-w-6xl flex flex-col min-h-screen">
      <main className="flex-grow">
        <header className="text-center mb-8">
          <div className="flex flex-col items-center justify-center mb-4">
            <ShrinkJetLogo className="w-24 h-24 md:w-28 md:h-28 mb-2" />
            <h1 className="text-4xl sm:text-5xl font-bold text-primary tracking-tight">ShrinkJet</h1>
          </div>
          <p className="text-lg sm:text-xl text-neutral mt-1">Crystal-clear JPEGs, perfectly sized for the web.</p>
        </header>

        <FileUpload onFilesUploaded={handleFilesUploaded} disabled={isBatchProcessing || isZipping} />

        {uploadedImages.length > 0 && (
          <>
            <BatchControls
              images={uploadedImages}
              onBatchCompress={handleBatchCompress}
              onDownloadZip={handleDownloadZip}
              isBatchProcessing={isBatchProcessing}
              isZipping={isZipping}
              globalQuality={globalCompressionQuality}
              setGlobalQuality={setGlobalCompressionQuality}
            />
          </>
        )}

        {uploadedImages.length === 0 && !isBatchProcessing && (
           <div className="mt-12 text-center text-gray-500">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
              </svg>
              <h3 className="mt-2 text-sm font-medium text-gray-900">No images uploaded</h3>
              <p className="mt-1 text-sm text-gray-500">Get started by uploading some JPEG files.</p>
            </div>
        )}

        <div className="grid grid-cols-1 gap-6 mt-8">
          {uploadedImages.map((imageFile) => (
            <ImagePreviewCard
              key={imageFile.id}
              imageFile={imageFile}
              onCompress={handleCompressImage}
              onRemove={handleRemoveImage}
              onUpdateSettings={handleUpdateImageSettings}
            />
          ))}
        </div>
      </main>
       <footer className="mt-12 py-6 border-t border-gray-300 dark:border-gray-700">
        <div className="container mx-auto px-4 flex flex-col sm:flex-row justify-center items-center gap-4"> {/* Changed justify-between to justify-center */}
          <p className="text-sm text-gray-500 dark:text-gray-400 text-center sm:text-left">
            JPEG Image compressor &copy; {new Date().getFullYear()}. Powered by ShrinkJet.
          </p>
          {/* DonationButton removed */}
        </div>
      </footer>
    </div>
  );
};

export default App;
